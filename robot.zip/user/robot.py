import time
import sr.robot

R = sr.robot.Robot()

R.motors[0].m0.power = 65
R.motors[0].m1.power = 65
time.sleep(1)
R.motors[0].m0.power = -65
R.motors[0].m1.power = 65
time.sleep(1)
